<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('subjects', function (Blueprint $table) {
            $table->id(); // subject_id but using Laravel standard
            $table->foreignId('course_id')
                ->constrained('courses', 'course_id')
                ->cascadeOnDelete();
            $table->string('subject_code')->unique();
            $table->string('subject_name');
            $table->unsignedTinyInteger('units')->default(3);
            $table->enum('type', ['lecture', 'laboratory'])->default('lecture');
            $table->unsignedTinyInteger('hours_per_week')->default(3);
            $table->text('description')->nullable();

            $table->enum('semester', ['1st', '2nd', 'Summer'])->nullable();
            $table->integer('year_level')->nullable(); // 1–4

             // Self-referencing prerequisite
            $table->foreignId('subject_prerequisite_id')
                ->nullable()
                ->constrained('subjects', 'id')
                ->nullOnDelete();

                
            $table->timestamps();
        });

        Schema::create('subjects', function (Blueprint $table) {




            // lecture / laboratory
            

            // number of hours per week (e.g., 3, 6)
            

            

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('subjects');
    }
};
