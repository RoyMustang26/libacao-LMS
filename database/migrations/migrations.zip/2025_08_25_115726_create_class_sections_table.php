<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('class_sections', function (Blueprint $table) {
            $table->id();
            $table->foreignId('course_id')->constrained('courses', 'course_id')->cascadeOnDelete();

            // Academic period
            $table->foreignId('school_year_id')
                ->constrained('school_years', 'school_year_id')
                ->cascadeOnDelete();

            $table->foreignId('semester_id')
                ->constrained('semesters', 'semester_id')
                ->cascadeOnDelete();

            // Metadata
            $table->unsignedTinyInteger('year_level');   // 1-4
            $table->string('section_name');              // e.g., "II-IT2", "I-CS1"

            $table->unsignedSmallInteger('capacity')->nullable();

              // Prevent duplicates
            $table->unique(
                ['course_id', 'year_level', 'school_year_id', 'semester_id', 'section_name'],
                'unique_section_per_period'
            );

            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('class_sections');
    }
};