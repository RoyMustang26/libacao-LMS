<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
     public function up(): void
    {
        Schema::create('section_subjects', function (Blueprint $table) {
            $table->id();

            $table->foreignId('section_id')
                ->constrained('sections')
                ->cascadeOnDelete();

            $table->foreignId('subject_id')
                ->constrained('subjects')
                ->cascadeOnDelete();

            // Prevent a section from having the same subject twice
            $table->unique(
                ['section_id', 'subject_id'],
                'unique_section_subject'
            );

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('section_subjects');
    }
};